Insert into SHIPPERS (SHIPPERID,COMPANYNAME,PHONE) values (1,'Speedy Express','(503) 555-9831');
Insert into SHIPPERS (SHIPPERID,COMPANYNAME,PHONE) values (2,'United Package','(503) 555-3199');
Insert into SHIPPERS (SHIPPERID,COMPANYNAME,PHONE) values (3,'Federal Shipping','(503) 555-9931');
