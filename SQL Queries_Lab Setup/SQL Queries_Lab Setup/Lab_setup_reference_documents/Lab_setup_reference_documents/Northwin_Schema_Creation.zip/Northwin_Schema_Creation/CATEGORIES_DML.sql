Insert into CATEGORIES (CATEGORYID,CATEGORYNAME,DESCRIPTION) values (1,'Beverages','Soft drinks, coffees, teas, beers, and ales');
Insert into CATEGORIES (CATEGORYID,CATEGORYNAME,DESCRIPTION) values (2,'Condiments','Sweet and savory sauces, relishes, spreads, and seasonings');
Insert into CATEGORIES (CATEGORYID,CATEGORYNAME,DESCRIPTION) values (3,'Confections','Desserts, candies, and sweet breads');
Insert into CATEGORIES (CATEGORYID,CATEGORYNAME,DESCRIPTION) values (4,'Dairy Products','Cheeses');
Insert into CATEGORIES (CATEGORYID,CATEGORYNAME,DESCRIPTION) values (5,'Grains/Cereals','Breads, crackers, pasta, and cereal');
Insert into CATEGORIES (CATEGORYID,CATEGORYNAME,DESCRIPTION) values (6,'Meat/Poultry','Prepared meats');
Insert into CATEGORIES (CATEGORYID,CATEGORYNAME,DESCRIPTION) values (7,'Produce','Dried fruit and bean curd');
Insert into CATEGORIES (CATEGORYID,CATEGORYNAME,DESCRIPTION) values (8,'Seafood','Seaweed and fish');
